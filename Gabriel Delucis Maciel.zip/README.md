# Trabalho de IPPD

**Reconhecimento de blocos em frames de arquivos YUV usando OpenMPI**

1. Leitura do frame referência    - OK
2. Leitura do frame de comparação - OK
3. Comparação bloco a bloco       - OK
4. Print de resultados            -OK

Para executar:
./main [frame1] [frame2] 

onde [frame1] e [frame2] são números inteiros, referentes ao número do frame
